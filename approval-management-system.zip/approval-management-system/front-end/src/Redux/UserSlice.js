import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  ApplyFormData: [],
  ApplyUserProfile:[],
  UserLoginEmail:""
 
};
const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    setApplyFormData(state, action) {
      state.ApplyFormData = action.payload;
    },
    setApplyUserProfile(state, action) {
      state.ApplyUserProfile = action.payload;
    },
    setUserLoginEmail(state, action) {
      state.UserLoginEmail = action.payload;
    },
  },
});
export const { setApplyFormData ,setApplyUserProfile,setUserLoginEmail} = userSlice.actions;

export default userSlice.reducer;
