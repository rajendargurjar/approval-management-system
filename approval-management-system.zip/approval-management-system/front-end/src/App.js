import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Login from "./Components/AuthPage/LogIn";
import Signup from "./Components/AuthPage/Signup";
import Joblist from "./Components/Employ/JobList";
import Hrjoblist from "./Components/HR/Hrjoblist";
import ApplyJob from "./Components/Employ/ApplyJob";
import AddJobs from "./Components/HR/AddJobs";
import ApplyUsers from "./Components/HR/ApplyUsers";

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/joblist" element={<Joblist />} />
          <Route path="/hrjoblist" element={<Hrjoblist />} />
          <Route path="/applyJob" element={<ApplyJob />} />
          <Route path="/addJobs" element={<AddJobs />} />
          <Route path="/applyUsers" element={<ApplyUsers />} />

        </Routes>
      </div>
    </Router>
  );
}

export default App;
