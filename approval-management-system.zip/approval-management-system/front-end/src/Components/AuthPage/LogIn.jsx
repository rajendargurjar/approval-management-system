import axios from "axios";
import React, { useEffect, useState } from "react";
import toast, { Toaster } from "react-hot-toast";
import { useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { setUserLoginEmail } from "../../Redux/UserSlice";

const Login = () => {
  const dispatch = useDispatch();
  const apiurl = process.env.REACT_APP_API_URL;
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [Profile, setProfile] = useState("");
  const naviget=useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const data = { email, password, userProfile: Profile };
      const res = await axios.post(`${apiurl}/auth/login`, data);
      console.log("res",res)

      if (res.data.userProfile === "employ") {
        naviget("/joblist");
      dispatch(setUserLoginEmail(email));
      } else if (res.data.userProfile === "HR") {
        naviget("/hrjoblist");
      dispatch(setUserLoginEmail(email));
      }
    } catch (error) {
      // console.error("Error during signup:", error);
      toast.error(`${error.response.data.error}`)
    }
  };
  useEffect(() => {
    Swal.fire({
      text: "Login as a HR/Employ",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Employ",
      cancelButtonText: "HR",
    }).then((result) => {
      if (result.isConfirmed) {
        setProfile("employ");
      } else if (result.isDismissed) {
        setProfile("HR");
      }
    });
  }, []);
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <Toaster position="top-center" reverseOrder={false} />

      <div className="w-full max-w-md p-8 space-y-3 bg-white rounded shadow-md">
        <h2 className="text-2xl font-bold text-center">Login</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label
              className="block text-sm font-medium text-gray-700"
              htmlFor="email"
            >
              Email
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring focus:ring-blue-200"
              placeholder="Enter your email"
            />
          </div>
          <div>
            <label
              className="block text-sm font-medium text-gray-700"
              htmlFor="password"
            >
              Password
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring focus:ring-blue-200"
              placeholder="Enter your password"
            />
          </div>
          <button
            type="submit"
            className="w-full p-2 text-white bg-blue-500 rounded hover:bg-blue-600"
          >
            Login
          </button>
        </form>
        <p className="text-sm text-center">
          Don't have an account?{" "}
          <Link to={"/signup"} className="text-blue-500 hover:underline">
            Sign Up
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Login;
