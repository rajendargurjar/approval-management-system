import axios from "axios";
import React, { useEffect, useState } from "react";
import { IoLocationOutline } from "react-icons/io5";
import { IoBagCheckOutline } from "react-icons/io5";
import { MdOutlineCurrencyRupee } from "react-icons/md";
import { IoSearchOutline } from "react-icons/io5"; 
import { useNavigate } from "react-router-dom";

import { useDispatch } from 'react-redux';
import { setApplyFormData } from "../../Redux/UserSlice";

const JobList = () => {
  const [JobData, setJobData] = useState([]);
  const [searchQuery, setSearchQuery] = useState(""); 

  const apiurl = process.env.REACT_APP_API_URL;
  const navoget=useNavigate()
  const dispatch = useDispatch();

  useEffect(() => {
    const Getdata = async () => {
      try {
        const res = await axios.get(`${apiurl}/jobs/get`);
        setJobData(res.data);
      } catch (error) {
        console.log(error);
      }
    };
    Getdata();
  }, []);

  // Filter JobData based on search input
  const filteredJobs = JobData.filter((job) =>
    job.jobName.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const HandleClick=(item)=>{
    dispatch(setApplyFormData(item));
    navoget("/applyJob")
  }
  return (
    <>
      <div className="w-full">
        <div className="w-[80%] m-auto py-4">
          <div className="flex items-center bg-gray-100 rounded-lg p-2 mb-4 sticky top-4">
            <IoSearchOutline className="text-xl text-gray-600 mr-2" />
            <input
              type="text"
              className="w-full bg-transparent outline-none"
              placeholder="Search job by name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)} 
            />
          </div>

          {/* Job Listings */}
          {filteredJobs.map((item, index) => (
            <div
              key={index}
              className="bg-gray-200 w-full mt-4 rounded-lg p-2 px-8"
            >
              <h1 className="text-[1.5rem] font-bold">{item.jobName}</h1>
              <h4 className="font-bold">{item.companyName}</h4>
              <div className="flex gap-4 my-2">
                <p className="flex gap-1 items-center">
                  <IoBagCheckOutline />
                  {item.experience}
                </p>
                <p className="flex gap-1 items-center">
                  <MdOutlineCurrencyRupee /> {item.salary}
                </p>
                <p className="flex gap-1 items-center">
                  <IoLocationOutline /> {item.location}
                </p>
              </div>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam
                tempore, eius ut iste a totam enim dolores, tempora id quidem
                voluptate?
              </p>
              <p className="flex gap-1 text-gray-600 text-[.9rem]">
                Skills:
                {item.skills.map((skill, i) => (
                  <span key={i}>{skill}</span>
                ))}
              </p>
              <div className="flex justify-end">
                <button className="bg-blue-500 text-white px-4 py-2 rounded" onClick={()=>HandleClick(item)}>
                  Apply
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default JobList;
