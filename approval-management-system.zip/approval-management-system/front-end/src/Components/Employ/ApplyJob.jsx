import axios from "axios";
import React, { useState } from "react";
import { useSelector } from "react-redux";
import { Toaster } from 'react-hot-toast';
import toast from "react-hot-toast";
import { IoMdArrowRoundBack } from "react-icons/io";
import { useNavigate } from "react-router-dom";

const ApplyJob = () => {
    const naviget=useNavigate()
  const apiurl = process.env.REACT_APP_API_URL;
  const applyFormData = useSelector((state) => state.user.ApplyFormData);
  //   console.log("applyFormData",applyFormData._id)
  const JobId = applyFormData._id;
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    contact: "",
    resumePdf: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async () => {
      const res = await axios.post(`${apiurl}/jobs/apply/${JobId}`,formData);
      toast.success(`${res.data.message}`)
      setFormData({
        name: "",
        email: "",
        contact: "",
        resumePdf: "",
      })
  };

  return (
    <div className="max-w-md mx-auto mt-10">
      <Toaster position="top-center" reverseOrder={false} />
      <div className="text-2xl font-bold flex justify-between items-center">
      <h2 className=" ">Job Application Form</h2>
      </div>
      <div className="space-y-4 mt-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Name
          </label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring focus:ring-blue-300"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Email
          </label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring focus:ring-blue-300"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Contact Number
          </label>
          <input
            type="tel"
            name="contact"
            value={formData.contact}
            onChange={handleChange}
            required
            pattern="[0-9]{10}" // Simple pattern for 10-digit numbers
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring focus:ring-blue-300"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Resume URL
          </label>
          <input
            type="text"
            name="resumePdf"
            required
            value={formData.resumePdf}
            onChange={handleChange}
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring focus:ring-blue-300"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-blue-600 text-white font-semibold py-2 rounded-md hover:bg-blue-700 transition duration-200"
          onClick={handleSubmit}
        >
          Submit
        </button>
      </div>
    </div>
  );
};

export default ApplyJob;
