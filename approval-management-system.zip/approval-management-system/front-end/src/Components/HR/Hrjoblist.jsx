import axios from "axios";
import React, { useEffect, useState } from "react";
import { IoLocationOutline } from "react-icons/io5";
import { IoBagCheckOutline } from "react-icons/io5";
import { MdOutlineCurrencyRupee } from "react-icons/md";
import { IoSearchOutline } from "react-icons/io5";
import { useNavigate } from "react-router-dom";
import { FaUsers } from "react-icons/fa";

import { useDispatch, useSelector } from "react-redux";
import { setApplyUserProfile } from "../../Redux/UserSlice";

const Hrjoblist = () => {
  const LoginEmail = useSelector(
    (state) => state.user.UserLoginEmail
  );
  const [JobData, setJobData] = useState([]);
  // console.log("JobData", JobData);
  const [searchQuery, setSearchQuery] = useState("");

  const apiurl = process.env.REACT_APP_API_URL;
  const navoget = useNavigate();
  const dispatch = useDispatch();

  useEffect(() => {
    const Getdata = async () => {
      try {
        const res = await axios.post(`${apiurl}/jobs/gethrdata`, {
          emailId: LoginEmail,
        });
        setJobData(res.data);
      } catch (error) {
        console.log(error);
      }
    };
    Getdata();
  }, []);
  const filteredJobs = JobData.filter((job) =>
    job.jobName.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const HandleClick = (item) => {
    dispatch(setApplyUserProfile(item));
    navoget("/applyUsers");
  };
  const handlejobs=()=>{
    navoget("/addJobs");
  }
  return (
    <>
      <div className="w-full">
        <div className="w-[80%] m-auto py-4">
          <div className="flex items-center bg-gray-100 rounded-lg p-2 mb-4 sticky top-4">
            <IoSearchOutline className="text-xl text-gray-600 mr-2" />
            <input
              type="text"
              className="w-full bg-transparent outline-none"
              placeholder="Search job by name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex justify-end">

          <button  className="bg-blue-500 text-white px-4 py-2 rounded" onClick={handlejobs}>Add Jobs</button>
          </div>

          {/* Job Listings */}
          {filteredJobs.map((item, index) => {
            const applicantsLength = Array.isArray(item.applicants)
              ? item.applicants.length
              : 0;
            // console.log(`Item ${index} has ${applicantsLength} applicants.`);
            return (
              <>
                <div
                  key={index}
                  className="bg-gray-200 w-full mt-4 rounded-lg p-2 px-8"
                >
                  <h1 className="text-[1.5rem] font-bold">{item.jobName}</h1>
                  <h4 className="font-bold">{item.companyName}</h4>
                  <div className="flex gap-4 my-2">
                    <p className="flex gap-1 items-center">
                      <IoBagCheckOutline />
                      {item.experience}
                    </p>
                    <p className="flex gap-1 items-center">
                      <MdOutlineCurrencyRupee /> {item.salary}
                    </p>
                    <p className="flex gap-1 items-center">
                      <IoLocationOutline /> {item.location}
                    </p>
                  </div>
                  <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Quam tempore, eius ut iste a totam enim dolores, tempora id
                    quidem voluptate?
                  </p>
                  <p className="flex gap-1 text-gray-600 text-[.9rem]">
                    Skills:
                    {item.skills.map((skill, i) => (
                      <span key={i}>{skill}</span>
                    ))}
                  </p>
                  <div className="flex justify-between">
                    <div className="flex items-center gap-2">
                      <p>Apply for this Job</p>{" "}
                      <p className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white">
                        {" "}
                        {applicantsLength}
                      </p>
                      <p className="text-[1.5rem]">
                        <FaUsers />
                      </p>
                    </div>
                    <button
                      className="bg-blue-500 text-white px-4 py-2 rounded"
                      onClick={() => HandleClick(item)}
                    >
                      Applications
                    </button>
                  </div>
                </div>
              </>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default Hrjoblist;
