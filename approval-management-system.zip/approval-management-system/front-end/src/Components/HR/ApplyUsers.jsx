import axios from "axios";
import React, { useState } from "react";
import toast, { Toaster } from "react-hot-toast";
import { useSelector } from "react-redux";

const ApplyUsers = () => {
  const apiurl = process.env.REACT_APP_API_URL;
  const ApplyUserProfileData = useSelector(
    (state) => state.user.ApplyUserProfile
  );
  // console.log("ApplyUserProfileData", ApplyUserProfileData);
  const applicants = ApplyUserProfileData.applicants || [];

  // State for search input
  const [searchQuery, setSearchQuery] = useState("");

  // Function to handle search input change
  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  // Filter applicants based on search query
  const filteredApplicants = applicants.filter((applicant) =>
    applicant.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const handleAction = async (e, i) => {
    try {
      const res = await axios.post(
        `${apiurl}/jobs/status/${ApplyUserProfileData._id}/${e._id}`,
        {
          status: i,
        }
      );
      // console.log("res", res);
      if(i==="Reject"){
      toast.error("Rejected!")
      }
      else if(i==="Approve"){
      toast.success("Approved!")
      }
    } catch (error) {
      console.log(error);
      toast.error("Api Error")
    }
  };
  return (
    <>
      <div className="w-full">
      <Toaster position="top-center" reverseOrder={false} />
        <div className="lg:w-[50%] w-[80%] m-auto py-4">
          <p className="w-full text-center my-4 text-2sm font-bold">
            ApplyUsers Profile
          </p>

          {/* Search Input Field */}
          <div className="mb-4 sticky top-6">
            <input
              type="text"
              placeholder="Search by name"
              value={searchQuery}
              onChange={handleSearchChange}
              className="w-full p-2 border border-gray-300 rounded-lg"
            />
          </div>

          {/* Display filtered applicants */}
          {filteredApplicants.map((applicant, index) => {
            return (
              <div
                key={index}
                className="bg-gray-100 rounded-lg mb-4 p-4 flex flex-col gap-2"
              >
                <h1 className="text-[1.2rem] font-bold">
                  Name: {applicant.name}
                </h1>
                <p>EmailId: {applicant.email}</p>
                <p>Contact: {applicant.contact}</p>
                <p>ResumeUrl: {applicant.resumePdf}</p>

                <div className="flex justify-end">
                  <button
                    className="bg-green-500 text-white py-2 px-4 rounded mr-2"
                    onClick={() => handleAction(applicant, "Approve")}
                  >
                    Approve
                  </button>
                  <button
                    className="bg-red-500 text-white py-2 px-4 rounded"
                    onClick={() => handleAction(applicant, "Reject")}
                  >
                    Reject
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default ApplyUsers;
