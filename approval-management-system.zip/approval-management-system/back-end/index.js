const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const jobRoutes=require('./routes/Addjobs')

// const app = express();
// app.use(express.json());
const app = express();
app.use(cors()); // Enable CORS
app.use(express.json());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/Approval_managment', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Use auth routes
app.use('/api/auth', authRoutes);
app.use('/api/jobs', jobRoutes);
// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
