const express = require('express');
const Job = require('../Model/AddJob'); // Assuming your Job model is in the ../Model directory
const router = express.Router();

// Add Job Route
router.post('/add', async (req, res) => {
    const { jobName, experience, location, salary, skills, companyName, emailId } = req.body;

    if (!emailId) {
        return res.status(400).json({ error: 'Email is required' });
    }

    try {
        const job = new Job({ jobName, experience, location, salary, skills, companyName, emailId });
        await job.save();
        res.status(201).json({ message: 'Job added successfully', job });
    } catch (error) {
        res.status(400).json({ error: 'Error adding job', details: error.message });
    }
});

router.post('/apply/:jobId', async (req, res) => {
    const { jobId } = req.params;
    const { name, email, contact, resumePdf } = req.body;

    if (!name || !email || !contact || !resumePdf) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    try {
        const job = await Job.findById(jobId);
        if (!job) {
            return res.status(404).json({ error: 'Job not found' });
        }
        // Push new applicant details to the applicants array
        job.applicants.push({ name, email, contact, resumePdf,status: 'Applied' });
        await job.save();
        res.status(200).json({ message: 'Application submitted successfully', job });
    } catch (error) {
        res.status(500).json({ error: 'Error applying for the job', details: error.message });
    }
});




router.post('/status/:jobId/:applicantId', async (req, res) => {
    const { jobId, applicantId } = req.params;
    const { status } = req.body;

    if (!status) {
        return res.status(400).json({ error: 'Status is required' });
    }

    try {
        const job = await Job.findById(jobId);
        if (!job) {
            return res.status(404).json({ error: 'Job not found' });
        }

        // Find the applicant by ID
        const applicant = job.applicants.id(applicantId);
        if (!applicant) {
            return res.status(404).json({ error: 'Applicant not found' });
        }

        // Update the applicant's status
        applicant.status = status;
        await job.save();

        res.status(200).json({ message: 'Applicant status updated successfully', applicant });
    } catch (error) {
        res.status(500).json({ error: 'Error updating applicant status', details: error.message });
    }
});








// Get All Jobs Route
router.get('/get', async (req, res) => {
    try {
        const jobs = await Job.find(); // Correctly fetch all jobs from the database
        if (jobs.length === 0) {
            return res.status(404).json({ message: 'No jobs found' });
        }
        res.status(200).json(jobs);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching jobs', details: error.message });
    }
});

module.exports = router;


// get Data with help of email id 
router.post('/gethrdata', async (req, res) => {
    try {
        const { emailId } = req.body; // Get emailId from the request body

        // Fetch jobs matching the provided emailId
        const jobs = await Job.find({ emailId }); 

        if (jobs.length === 0) {
            return res.status(404).json({ message: 'No jobs found for the specified emailId' });
        }

        res.status(200).json(jobs);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching jobs', details: error.message });
    }
})
