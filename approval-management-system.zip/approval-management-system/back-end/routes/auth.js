const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../Model/User');

const router = express.Router();

// Signup Route
router.post('/signup', async (req, res) => {
    const { username, email, password, userProfile } = req.body;

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ username, email, password: hashedPassword, userProfile });

        await user.save();

        res.status(201).json({ message: 'User created successfully', userProfile });
    } catch (error) {
        res.status(400).json({ error: 'Error creating user' });
    }
});
// Login Route
router.post('/login', async (req, res) => {
    const { email, password, userProfile } = req.body; // Include userProfile in the request

    try {
        // Find the user by email
        const user = await User.findOne({ email });

        // Check if user exists, and if the password matches
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        // Check if userProfile matches
        if (user.userProfile !== userProfile) {
            return res.status(401).json({ error: 'User profile does not match' });
        }

        // Create a JWT token
        const token = jwt.sign({ userId: user._id, userProfile: user.userProfile }, 'your_jwt_secret', { expiresIn: '1h' });

        // Successful login response
        return res.status(200).json({
            message: 'Login successful',
            token,
            userProfile: user.userProfile,
        });

    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});
module.exports = router;
