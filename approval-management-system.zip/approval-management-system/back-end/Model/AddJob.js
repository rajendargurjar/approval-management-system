// const mongoose = require('mongoose');

// const JobSchema = new mongoose.Schema({
//     jobName: { type: String, required: true },
//     experience: { type: String, required: true }, // You can use String to describe years/experience level
//     location: { type: String, required: true },
//     salary: { type: Number, required: true },
//     skills: { type: [String], required: true }, // Array of skills
//     companyName: { type: String, required: true },
//     emailId: { type: String, required: true }, // Email of the user who created the job
// }, { timestamps: true }); // Automatically add createdAt and updatedAt fields

// const Job = mongoose.model('Job', JobSchema);
// module.exports = Job;


const mongoose = require('mongoose');

const jobSchema = new mongoose.Schema({
    jobName: { type: String, required: true },
    experience: { type: String, required: true },
    location: { type: String, required: true },
    salary: { type: Number, required: true },
    skills: { type: [String], required: true },
    companyName: { type: String, required: true },
    emailId: { type: String, required: true },
    applicants: [{
        name: String,
        email: String,
        contact: String,
        resumePdf: String,
        status:String,
    }]
}, { timestamps: true });

const Job = mongoose.model('Job', jobSchema);
module.exports = Job;
